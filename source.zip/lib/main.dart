import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ToDo4ToDayApp());
}

const brown = Color(0xFF5D4037);
const darkBrown = Color(0xFF3E2723);
const yellow = Color(0xFFFFC857);
const cream = Color(0xFFFFF8E8);

String dateKey(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
String timeKey(TimeOfDay? t) => t == null ? '' : '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
TimeOfDay? parseTime(String? s) {
  if (s == null || s.isEmpty || !s.contains(':')) return null;
  final p = s.split(':');
  final h = int.tryParse(p[0]), m = int.tryParse(p[1]);
  if (h == null || m == null || h < 0 || h > 23 || m < 0 || m > 59) return null;
  return TimeOfDay(hour: h, minute: m);
}

class TaskItem {
  TaskItem({
    required this.id,
    required this.title,
    this.description = '',
    required this.targetMinutes,
    this.scheduledTime,
    this.completed = false,
    this.startedAt,
    this.completedAt,
    this.elapsedBeforeStart = 0,
    this.actualSeconds = 0,
    this.extensionMinutes = 0,
  });

  final String id;
  String title;
  String description;
  int targetMinutes;
  String scheduledTime;
  bool completed;
  DateTime? startedAt;
  DateTime? completedAt;
  int elapsedBeforeStart;
  int actualSeconds;
  int extensionMinutes;

  int elapsedNow() => elapsedBeforeStart +
      (startedAt == null ? 0 : DateTime.now().difference(startedAt!).inSeconds);

  void resetForNewDay() {
    completed = false;
    startedAt = null;
    completedAt = null;
    elapsedBeforeStart = 0;
    actualSeconds = 0;
    extensionMinutes = 0;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'targetMinutes': targetMinutes,
        'scheduledTime': scheduledTime,
        'completed': completed,
        'startedAt': startedAt?.toIso8601String(),
        'completedAt': completedAt?.toIso8601String(),
        'elapsedBeforeStart': elapsedBeforeStart,
        'actualSeconds': actualSeconds,
        'extensionMinutes': extensionMinutes,
      };

  factory TaskItem.fromJson(Map<String, dynamic> j) => TaskItem(
        id: j['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
        title: j['title']?.toString() ?? 'Tâche',
        description: j['description']?.toString() ?? '',
        targetMinutes: (j['targetMinutes'] as num?)?.toInt() ?? 30,
        scheduledTime: j['scheduledTime']?.toString() ?? '',
        completed: j['completed'] == true,
        startedAt: j['startedAt'] == null ? null : DateTime.tryParse(j['startedAt'].toString()),
        completedAt: j['completedAt'] == null ? null : DateTime.tryParse(j['completedAt'].toString()),
        elapsedBeforeStart: (j['elapsedBeforeStart'] as num?)?.toInt() ?? 0,
        actualSeconds: (j['actualSeconds'] as num?)?.toInt() ?? 0,
        extensionMinutes: (j['extensionMinutes'] as num?)?.toInt() ?? 0,
      );
}

class ToDo4ToDayApp extends StatelessWidget {
  const ToDo4ToDayApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ToDo4ToDay by RTNA',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: cream,
          colorScheme: ColorScheme.fromSeed(seedColor: brown, primary: brown, secondary: yellow),
          appBarTheme: const AppBarTheme(backgroundColor: brown, foregroundColor: Colors.white),
          floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: yellow, foregroundColor: darkBrown),
        ),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  final List<TaskItem> tasks = [];
  final List<Map<String, dynamic>> dailyHistory = [];
  Timer? ticker;
  final AudioPlayer _endSoundPlayer = AudioPlayer();
  int tab = 0;
  bool loading = true;
  String currentDay = dateKey(DateTime.now());
  final Set<String> _targetDialogs = <String>{};

  Future<void> _playEndSound() async {
    try {
      await _endSoundPlayer.stop();
      await _endSoundPlayer.play(AssetSource('sounds/task_finished.wav'));
    } catch (e) {
      debugPrint('Impossible de jouer le son de fin : $e');
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    loadTasks();
    ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      _ensureCurrentDay();
      if (mounted) setState(() {});
      _checkTargets();
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _ensureCurrentDay();
  }

  @override
  void dispose() {
    ticker?.cancel();
    _endSoundPlayer.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> loadTasks() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('tasks');
    final historyRaw = p.getString('dailyHistory');
    currentDay = p.getString('currentDay') ?? dateKey(DateTime.now());
    if (raw != null) {
      try {
        tasks.addAll((jsonDecode(raw) as List).map((e) => TaskItem.fromJson(Map<String, dynamic>.from(e))));
      } catch (e) { debugPrint('Lecture des tâches impossible: $e'); }
    }
    if (historyRaw != null) {
      try {
        dailyHistory.addAll((jsonDecode(historyRaw) as List).map((e) => Map<String, dynamic>.from(e)));
      } catch (e) { debugPrint('Lecture de l’historique impossible: $e'); }
    }
    await _ensureCurrentDay();
    if (mounted) setState(() => loading = false);
  }

  Future<void> saveTasks() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('tasks', jsonEncode(tasks.map((e) => e.toJson()).toList()));
    await p.setString('dailyHistory', jsonEncode(dailyHistory));
    await p.setString('currentDay', currentDay);
  }

  Future<void> _ensureCurrentDay() async {
    final today = dateKey(DateTime.now());
    if (today == currentDay) return;
    if (tasks.isNotEmpty) {
      dailyHistory.add({
        'date': currentDay,
        'tasks': tasks.map((t) => {
          'id': t.id,
          'title': t.title,
          'scheduledTime': t.scheduledTime,
          'targetMinutes': t.targetMinutes,
          'completed': t.completed,
          'actualSeconds': t.completed ? t.actualSeconds : t.elapsedNow(),
          'completedAt': t.completedAt?.toIso8601String(),
        }).toList(),
      });
      if (dailyHistory.length > 90) dailyHistory.removeRange(0, dailyHistory.length - 90);
    }
    for (final t in tasks) t.resetForNewDay();
    currentDay = today;
    await saveTasks();
    if (mounted) setState(() {});
  }

  Map<String, dynamic>? _previousRecord(String taskId) {
    for (final day in dailyHistory.reversed) {
      final list = (day['tasks'] as List?) ?? [];
      for (final raw in list) {
        final record = Map<String, dynamic>.from(raw as Map);
        if (record['id']?.toString() == taskId) return {'date': day['date'], ...record};
      }
    }
    return null;
  }

  void _checkTargets() {
    for (final t in tasks) {
      final limit = (t.targetMinutes + t.extensionMinutes) * 60;
      if (t.startedAt != null && t.elapsedNow() >= limit && !_targetDialogs.contains(t.id)) {
        _targetDialogs.add(t.id);
        unawaited(_playEndSound());
        t.elapsedBeforeStart = t.elapsedNow();
        t.startedAt = null;
        saveTasks();
        WidgetsBinding.instance.addPostFrameCallback((_) => _targetDialog(t));
        break;
      }
    }
  }

  Future<void> _targetDialog(TaskItem t) async {
    try {
      if (!mounted || t.completed) return;
      final choice = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          title: const Text('Durée prévue atteinte'),
          content: Text('La durée prévue pour « ${t.title} » est écoulée. As-tu terminé ?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Continuer (+1 min)')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Oui, terminé')),
          ],
        ),
      );
      if (!mounted) return;
      if (choice == true) {
        t.completed = true;
        t.actualSeconds = t.elapsedBeforeStart;
        t.completedAt = DateTime.now();
      } else if (choice == false) {
        t.extensionMinutes += 1;
        t.startedAt = DateTime.now();
      }
      await saveTasks();
      if (mounted) setState(() {});
    } finally {
      _targetDialogs.remove(t.id);
    }
  }

  Future<void> addOrEdit({TaskItem? task}) async {
    final title = TextEditingController(text: task?.title ?? '');
    final desc = TextEditingController(text: task?.description ?? '');
    final mins = TextEditingController(text: '${task?.targetMinutes ?? 30}');
    TimeOfDay? chosenTime = parseTime(task?.scheduledTime);
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, refreshDialog) => AlertDialog(
        title: Text(task == null ? 'Nouvelle tâche' : 'Modifier la tâche'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: title, autofocus: true, decoration: const InputDecoration(labelText: 'Nom de la tâche')),
          TextField(controller: desc, decoration: const InputDecoration(labelText: 'Description'), maxLines: 2),
          TextField(controller: mins, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Durée prévue (minutes)')),
          const SizedBox(height: 10),
          Align(alignment: Alignment.centerLeft, child: Text('Heure prévue', style: TextStyle(color: Colors.brown.shade700))),
          OutlinedButton.icon(
            onPressed: () async {
              final picked = await showTimePicker(context: ctx, initialTime: chosenTime ?? TimeOfDay.now());
              if (picked != null) refreshDialog(() => chosenTime = picked);
            },
            icon: const Icon(Icons.schedule),
            label: Text(chosenTime == null ? 'Choisir une heure' : chosenTime!.format(ctx)),
          ),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer')),
        ],
      )),
    );
    if (result != true || title.text.trim().isEmpty) return;
    final n = (int.tryParse(mins.text.trim()) ?? 30).clamp(1, 1440);
    if (task == null) {
      tasks.add(TaskItem(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        title: title.text.trim(),
        description: desc.text.trim(),
        targetMinutes: n,
        scheduledTime: timeKey(chosenTime),
      ));
    } else {
      task.title = title.text.trim();
      task.description = desc.text.trim();
      task.targetMinutes = n;
      task.scheduledTime = timeKey(chosenTime);
    }
    await saveTasks();
    if (mounted) setState(() {});
  }

  Future<void> toggleTimer(TaskItem t) async {
    if (t.completed) return;
    if (t.startedAt == null) {
      t.startedAt = DateTime.now();
    } else {
      t.elapsedBeforeStart = t.elapsedNow();
      t.startedAt = null;
    }
    await saveTasks();
    setState(() {});
  }

  Future<void> finish(TaskItem t) async {
    t.actualSeconds = t.elapsedNow();
    t.elapsedBeforeStart = t.actualSeconds;
    t.startedAt = null;
    t.completed = true;
    t.completedAt = DateTime.now();
    await saveTasks();
    setState(() {});
  }

  Future<void> delete(TaskItem t) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Supprimer cette tâche ?'),
      content: Text('« ${t.title} » sera supprimée des tâches quotidiennes. Son historique passé sera conservé.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
      ],
    ));
    if (ok == true) {
      tasks.removeWhere((x) => x.id == t.id);
      await saveTasks();
      setState(() {});
    }
  }

  String duration(int s) {
    final h = s ~/ 3600, m = (s % 3600) ~/ 60, sec = s % 60;
    return h > 0 ? '${h}h ${m.toString().padLeft(2, '0')}m' : '${m}m ${sec.toString().padLeft(2, '0')}s';
  }

  String clockLabel(DateTime? d) => d == null ? '—' : '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final done = tasks.where((t) => t.completed).length;
    final total = tasks.length;
    return Scaffold(
      appBar: AppBar(title: Row(children: [
        Image.asset('assets/app_icon.png', width: 38, height: 38),
        const SizedBox(width: 9),
        const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('ToDo4ToDay', style: TextStyle(fontWeight: FontWeight.bold)),
          Text('by RTNA', style: TextStyle(fontSize: 11, color: yellow)),
        ]),
      ]), actions: [IconButton(onPressed: () => showAboutDialog(context: context, applicationName: 'ToDo4ToDay by RTNA', applicationVersion: '1.3.0', children: const [Text('Ton assistant quotidien, utilisable hors connexion.')]), icon: const Icon(Icons.info_outline))]),
      body: loading ? const Center(child: CircularProgressIndicator()) : tab == 0 ? _dashboard(done, total) : _stats(done, total),
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(onPressed: () => addOrEdit(), icon: const Icon(Icons.add), label: const Text('Ajouter')) : null,
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.checklist), label: 'Mes tâches'),
        NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Bilan'),
      ]),
    );
  }

  Widget _dashboard(int done, int total) {
    final active = tasks.where((t) => !t.completed).length;
    final sorted = [...tasks]..sort((a, b) {
      if (a.scheduledTime.isEmpty && b.scheduledTime.isEmpty) return 0;
      if (a.scheduledTime.isEmpty) return 1;
      if (b.scheduledTime.isEmpty) return -1;
      return a.scheduledTime.compareTo(b.scheduledTime);
    });
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: brown, borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Aujourd’hui, avance à ton rythme.', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        Text('Date : $currentDay', style: const TextStyle(color: Colors.white70, fontSize: 12)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _metric('$total', 'Tâches')),
          Expanded(child: _metric('$done', 'Terminées')),
          Expanded(child: _metric('${total == 0 ? 0 : (done * 100 / total).round()}%', 'Progression')),
        ]),
        const SizedBox(height: 10),
        ClipRRect(borderRadius: BorderRadius.circular(10), child: LinearProgressIndicator(value: total == 0 ? 0 : done / total, minHeight: 8, backgroundColor: Colors.white24, color: yellow)),
      ])),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Mes tâches', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: darkBrown)), Text('$active en cours', style: const TextStyle(color: brown))]),
      const SizedBox(height: 8),
      if (tasks.isEmpty) Container(padding: const EdgeInsets.all(28), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: const Column(children: [Icon(Icons.event_note, size: 42, color: brown), SizedBox(height: 8), Text('Aucune tâche pour le moment'), Text('Appuie sur Ajouter pour commencer.', style: TextStyle(color: Colors.black54))]))
      else ...sorted.map(_taskCard),
    ]);
  }

  Widget _metric(String value, String label) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(value, style: const TextStyle(color: yellow, fontSize: 22, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12))]);

  Widget _taskCard(TaskItem t) {
    final elapsed = t.completed ? t.actualSeconds : t.elapsedNow();
    final running = t.startedAt != null;
    final previous = _previousRecord(t.id);
    return Card(color: Colors.white, margin: const EdgeInsets.only(bottom: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(child: Text(t.title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, decoration: t.completed ? TextDecoration.lineThrough : null, color: darkBrown))),
        PopupMenuButton<String>(onSelected: (v) { if (v == 'edit') addOrEdit(task: t); if (v == 'delete') delete(t); }, itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Modifier')), PopupMenuItem(value: 'delete', child: Text('Supprimer'))]),
      ]),
      if (t.description.isNotEmpty) Text(t.description, style: const TextStyle(color: Colors.black54)),
      const SizedBox(height: 8),
      Row(children: [const Icon(Icons.schedule, size: 16, color: brown), const SizedBox(width: 4), Text('Heure : ${t.scheduledTime.isEmpty ? 'non définie' : t.scheduledTime}'), const Spacer(), const Icon(Icons.flag_outlined, size: 16, color: brown), const SizedBox(width: 4), Text('${t.targetMinutes} min prévues')]),
      const SizedBox(height: 5),
      Row(children: [const Icon(Icons.timer_outlined, size: 16, color: brown), const SizedBox(width: 4), Text('Écoulé : ${duration(elapsed)}')]),
      if (previous != null && t.completed && previous['completed'] == true && previous['completedAt'] != null && t.completedAt != null) ...[
        const SizedBox(height: 6),
        _comparisonLine(t.completedAt!, DateTime.tryParse(previous['completedAt'].toString()), 'Heure de fin vs ${previous['date']}'),
      ],
      const SizedBox(height: 10),
      if (!t.completed) Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: () => toggleTimer(t), icon: Icon(running ? Icons.pause : Icons.play_arrow), label: Text(running ? 'Pause' : 'Démarrer'))),
        const SizedBox(width: 8),
        Expanded(child: FilledButton.icon(onPressed: () => finish(t), icon: const Icon(Icons.check), label: const Text('Terminer'))),
      ]) else const Row(children: [Icon(Icons.check_circle, color: Colors.green), SizedBox(width: 6), Text('Terminée', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))]),
    ])));
  }

  Widget _comparisonLine(DateTime current, DateTime? previous, String label) {
    if (previous == null) return const SizedBox.shrink();
    final currentMinute = current.hour * 60 + current.minute;
    final previousMinute = previous.hour * 60 + previous.minute;
    final diff = currentMinute - previousMinute;
    final text = diff == 0 ? 'Même heure de fin qu’hier' : diff < 0 ? 'Terminée ${-diff} min plus tôt qu’auparavant' : 'Terminée $diff min plus tard qu’auparavant';
    final color = diff <= 0 ? Colors.green.shade700 : Colors.deepOrange;
    return Row(children: [Icon(diff <= 0 ? Icons.trending_up : Icons.trending_down, size: 16, color: color), const SizedBox(width: 4), Expanded(child: Text('$text (${clockLabel(previous)} → ${clockLabel(current)})', style: TextStyle(fontSize: 12, color: color)))]);
  }

  Widget _stats(int done, int total) {
    final seconds = tasks.fold<int>(0, (sum, t) => sum + (t.completed ? t.actualSeconds : t.elapsedNow()));
    final planned = tasks.fold<int>(0, (sum, t) => sum + t.targetMinutes * 60);
    final previousDay = dailyHistory.isEmpty ? null : dailyHistory.last;
    final previousTasks = previousDay == null ? <Map<String, dynamic>>[] : ((previousDay['tasks'] as List?) ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Mon bilan du jour', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: darkBrown)),
      const SizedBox(height: 14),
      _statTile(Icons.task_alt, 'Tâches terminées', '$done / $total'),
      _statTile(Icons.timer, 'Temps réellement consacré', duration(seconds)),
      _statTile(Icons.flag, 'Temps prévu cumulé', duration(planned)),
      _statTile(Icons.insights, 'Progression', '${total == 0 ? 0 : (done * 100 / total).round()} %'),
      const SizedBox(height: 16),
      const Text('Comparaison avec la journée précédente', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: darkBrown)),
      const SizedBox(height: 6),
      if (previousDay == null) const Text('Les comparaisons apparaîtront après une première journée enregistrée.', style: TextStyle(color: Colors.black54))
      else Text('Comparaison avec le ${previousDay['date']}', style: const TextStyle(color: Colors.black54)),
      const SizedBox(height: 8),
      ...tasks.map((t) {
        final old = previousTasks.where((e) => e['id']?.toString() == t.id).cast<Map<String, dynamic>?>().firstWhere((e) => e != null, orElse: () => null);
        final actual = t.completed ? t.actualSeconds : t.elapsedNow();
        final max = (t.targetMinutes * 60).clamp(1, 1000000000);
        String comparison = 'Pas encore de résultat précédent';
        Color comparisonColor = Colors.black54;
        if (old != null && old['completed'] == true && t.completed) {
          final oldSeconds = (old['actualSeconds'] as num?)?.toInt() ?? 0;
          final diff = actual - oldSeconds;
          comparison = diff == 0 ? 'Même durée que la fois précédente' : diff < 0 ? 'Durée réduite de ${duration(-diff)}' : 'Durée augmentée de ${duration(diff)}';
          comparisonColor = diff <= 0 ? Colors.green.shade700 : Colors.deepOrange;
          final oldFinish = old['completedAt'] == null ? null : DateTime.tryParse(old['completedAt'].toString());
          if (oldFinish != null && t.completedAt != null) {
            final delta = (t.completedAt!.hour * 60 + t.completedAt!.minute) - (oldFinish.hour * 60 + oldFinish.minute);
            comparison += delta == 0 ? ' • fin à la même heure' : delta < 0 ? ' • fin ${-delta} min plus tôt' : ' • fin $delta min plus tard';
          }
        }
        return Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t.title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: (actual / max).clamp(0.0, 1.0), minHeight: 9, color: actual > max ? Colors.deepOrange : brown, backgroundColor: Colors.brown.shade100)),
          Text('${duration(actual)} / ${t.targetMinutes} min prévues', style: const TextStyle(fontSize: 12, color: Colors.black54)),
          Text(comparison, style: TextStyle(fontSize: 12, color: comparisonColor)),
        ]));
      }),
      const SizedBox(height: 10),
      const Text('Les résultats quotidiens sont enregistrés sur cet appareil. Les tâches se réinitialisent automatiquement au changement de date.', style: TextStyle(color: Colors.black54)),
    ]);
  }

  Widget _statTile(IconData icon, String label, String value) => Card(color: Colors.white, child: ListTile(leading: Icon(icon, color: brown), title: Text(label), trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.bold, color: darkBrown))));
}
