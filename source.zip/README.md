# ToDo4ToDay by RTNA

Application Flutter de gestion quotidienne des tâches, utilisable hors connexion.

## Fonctionnalités
- Création, modification et suppression des tâches quotidiennes.
- Heure prévue et durée prévue pour chaque tâche.
- Chronomètre avec pause et reprise.
- À la fin de la durée prévue : son, choix « terminé » ou « continuer (+1 min) ».
- Réinitialisation des tâches au changement de journée, sans supprimer les résultats des jours précédents.
- Historique local des 90 dernières journées enregistrées.
- Comparaison de la durée réelle et de l'heure de fin avec la journée précédente.

Les données sont conservées localement sur l'appareil avec SharedPreferences. Aucun compte ni connexion Internet n'est nécessaire. La réinitialisation est appliquée lorsque l'application est ouverte ou revient au premier plan après un changement de date.
