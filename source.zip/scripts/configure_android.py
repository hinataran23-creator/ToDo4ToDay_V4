from pathlib import Path
import re
manifest = Path('android/app/src/main/AndroidManifest.xml')
s = manifest.read_text()
s = re.sub(r'android:label="[^"]*"', 'android:label="ToDo4ToDay"', s, count=1)
permissions = '''    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
'''
if 'android.permission.POST_NOTIFICATIONS' not in s:
    s = s.replace('<application', permissions + '    <application', 1)
receivers = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON" />
            </intent-filter>
        </receiver>
'''
if 'ScheduledNotificationReceiver' not in s:
    s = s.replace('</application>', receivers + '    </application>')
manifest.write_text(s)

# Scheduled notifications require Java API desugaring on Android.
gradle_kts = Path('android/app/build.gradle.kts')
gradle = Path('android/app/build.gradle')
if gradle_kts.exists():
    g = gradle_kts.read_text()
    if 'isCoreLibraryDesugaringEnabled' not in g:
        g = g.replace('compileOptions {', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', 1)
    if 'coreLibraryDesugaring(' not in g:
        g = g.replace('dependencies {', 'dependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")', 1)
    gradle_kts.write_text(g)
elif gradle.exists():
    g = gradle.read_text()
    if 'coreLibraryDesugaringEnabled' not in g:
        g = g.replace('compileOptions {', 'compileOptions {\n        coreLibraryDesugaringEnabled true', 1)
    if 'coreLibraryDesugaring ' not in g:
        g = g.replace('dependencies {', "dependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.4'", 1)
    gradle.write_text(g)
