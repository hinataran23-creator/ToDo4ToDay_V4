from pathlib import Path
import re

manifest = Path('android/app/src/main/AndroidManifest.xml')
s = manifest.read_text()
s = re.sub(r'android:label="[^"]*"', 'android:label="ToDo4ToDay"', s, count=1)
permissions = '''    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
'''
if 'android.permission.POST_NOTIFICATIONS' not in s:
    s = s.replace('<application', permissions + '    <application', 1)
receivers = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON" />
            </intent-filter>
        </receiver>
'''
if 'ScheduledNotificationReceiver' not in s:
    s = s.replace('</application>', receivers + '    </application>')
manifest.write_text(s)

# flutter_local_notifications needs Java API desugaring for scheduled notifications.
gradle_kts = Path('android/app/build.gradle.kts')
gradle = Path('android/app/build.gradle')
if gradle_kts.exists():
    p = gradle_kts
    g = p.read_text()
    if 'isCoreLibraryDesugaringEnabled = true' not in g:
        if re.search(r'compileOptions\s*\{', g):
            g = re.sub(r'(compileOptions\s*\{)', r'\1\n        isCoreLibraryDesugaringEnabled = true', g, count=1)
        else:
            g = re.sub(r'(android\s*\{)', r'\1\n    compileOptions {\n        isCoreLibraryDesugaringEnabled = true\n        sourceCompatibility = JavaVersion.VERSION_17\n        targetCompatibility = JavaVersion.VERSION_17\n    }', g, count=1)
    if 'coreLibraryDesugaring(' not in g:
        if re.search(r'dependencies\s*\{', g):
            g = re.sub(r'(dependencies\s*\{)', r'\1\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")', g, count=1)
        else:
            g += '\n\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
    p.write_text(g)
elif gradle.exists():
    p = gradle
    g = p.read_text()
    if 'coreLibraryDesugaringEnabled true' not in g:
        if re.search(r'compileOptions\s*\{', g):
            g = re.sub(r'(compileOptions\s*\{)', r'\1\n        coreLibraryDesugaringEnabled true', g, count=1)
        else:
            g = re.sub(r'(android\s*\{)', r'\1\n    compileOptions {\n        coreLibraryDesugaringEnabled true\n        sourceCompatibility JavaVersion.VERSION_17\n        targetCompatibility JavaVersion.VERSION_17\n    }', g, count=1)
    if "coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:" not in g:
        if re.search(r'dependencies\s*\{', g):
            g = re.sub(r'(dependencies\s*\{)', r"\1\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'", g, count=1)
        else:
            g += "\n\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
    p.write_text(g)
else:
    raise SystemExit('ERREUR : aucun fichier android/app/build.gradle(.kts) trouvé')

# Fail early rather than silently building without the required configuration.
final_gradle = gradle_kts if gradle_kts.exists() else gradle
configured = final_gradle.read_text()
if 'desugar_jdk_libs:2.1.4' not in configured:
    raise SystemExit('ERREUR : dépendance desugaring non configurée')
if 'CoreLibraryDesugaringEnabled = true' not in configured and 'coreLibraryDesugaringEnabled true' not in configured:
    raise SystemExit('ERREUR : core library desugaring non activé')
print(f'Desugaring configuré dans {final_gradle}')
